# Python
 Öğrenme sürecimdeki adımlar.
